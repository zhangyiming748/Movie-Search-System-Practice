#!/bin/env python 
#coding=utf-8

import requests
from bs4 import BeautifulSoup
import sys, argparse

from lxml import etree

if __name__ == '__main__':

	parser = argparse.ArgumentParser()
	parser.add_argument(
        "--url",
        default="https://movie.douban.com/subject/1292052/",
        help="豆瓣电影URL")
	args = parser.parse_args()
	uri = args.url
	if uri == "":
		raise ValueError
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36'}
	res = requests.get(uri, headers = headers)
	soup = BeautifulSoup(res.text)
	print("标题：{}".format(soup.find('h1').text.strip().split('\n')[0]))
	
	content = soup.find(id='info').text.strip().split('\n')
	for line in content:
		print(line)